# CS325-Project-Travelling-Salesman-Problem-Group9
Zheng Du		    duz@oregonstate.edu
Patrick Levy		levyp@oregonstate.edu
Trevor D Worthey	wortheyt@oregonstate.edu

#### To run the program
`Usage: ./tspDriver.py <PATH_TO_INPUT_FILE>`

`Example: ./tspDriver.py ./TSP_Files-1/tsp_example_1.txt`

#### Notes
- Please run this using Python 2.x
- Report is contained in this folder, titled "CS325-Project-Traveling-Salesman-Problem-Group9.pdf"